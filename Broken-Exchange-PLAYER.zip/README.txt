BROKEN EXCHANGE
Category: Crypto | Difficulty: Very Hard

----------------------------------------------------------------------

A secure channel was established using Diffie-Hellman. An intercepted
communication was recovered, but something about the exchange does not
look quite right.

Files:
  server.py            - leaked reference implementation of the protocol
  public_params.txt    - domain parameters advertised by the service
  transcript_01.txt     \
  transcript_02.txt      > captured handshake sessions
  transcript_03.txt     /
  encrypted_message.bin - protected payload referenced by transcript_01

Objective:
  Recover the plaintext of the protected message. It is formatted as
  AURA{...}.
