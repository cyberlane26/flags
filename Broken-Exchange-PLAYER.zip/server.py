#!/usr/bin/env python3
"""
BX-DH-v1 reference server implementation.
(Leaked from an internal tools repository - config/secrets stripped.)

This is the protocol implementation the service runs. Domain parameters
(p, g, q) are loaded from config at startup and advertised to clients as
part of the handshake (see PARAMETERS messages in captured transcripts).
"""
import os
import secrets as _secrets
from Crypto.Protocol.KDF import HKDF
from Crypto.Hash import SHA256
from Crypto.Cipher import AES

# --- Domain parameters -----------------------------------------------------
# Loaded from config at startup; see public_params.txt for the values
# advertised by this deployment.
p = None   # int, modulus
g = None   # int, generator
q = None   # int, published subgroup order used for key generation ranges

# --- Long-term server identity key -----------------------------------------
# Generated once at deployment time and reused across client sessions
# (standard practice for a server identity/static DH key).
_server_private_key = None          # int, kept secret
SERVER_PUBLIC_VALUE = None          # int, A = pow(g, _server_private_key, p)


def generate_ephemeral():
    """Caller-side (client) ephemeral keypair for one session."""
    b = _secrets.randbelow(p - 2) + 1
    B = pow(g, b, p)
    return b, B


def server_compute_shared(client_public_B):
    """Server side: combine its static key with the client's ephemeral B."""
    return pow(client_public_B, _server_private_key, p)


def client_compute_shared(server_public_A, client_private_b):
    """Client side: combine its ephemeral key with the server's static A."""
    return pow(server_public_A, client_private_b, p)


# --- Key derivation ----------------------------------------------------------
# Session key = HKDF-SHA256(shared_secret_bytes, salt=HKDF_SALT, info=HKDF_INFO)
# shared_secret is serialized as a big-endian integer, zero-padded to the
# byte length of p.
HKDF_SALT = bytes.fromhex("4272f6e1a8c4e2a9b7d1f0c3e5a6b8d9")
HKDF_INFO = b"broken-exchange-session-key-v1"


def derive_session_key(shared_secret_int):
    byte_len = (p.bit_length() + 7) // 8
    secret_bytes = shared_secret_int.to_bytes(byte_len, "big")
    return HKDF(secret_bytes, 32, HKDF_SALT, SHA256, 1, context=HKDF_INFO)


# --- Record layer -------------------------------------------------------------
# DATA records are AES-256-GCM: wire format is
#     nonce (12 bytes) || ciphertext || tag (16 bytes)
# with no associated data (AAD is empty).

def encrypt_record(session_key, plaintext):
    nonce = _secrets.token_bytes(12)
    cipher = AES.new(session_key, AES.MODE_GCM, nonce=nonce)
    ct, tag = cipher.encrypt_and_digest(plaintext)
    return nonce + ct + tag


def decrypt_record(session_key, blob):
    nonce, ct, tag = blob[:12], blob[12:-16], blob[-16:]
    cipher = AES.new(session_key, AES.MODE_GCM, nonce=nonce)
    return cipher.decrypt_and_verify(ct, tag)


# --- Session handler (simplified) --------------------------------------------
def handle_session(client_public_B):
    """
    Full server-side session flow, matching the PARAMETERS / PUBLIC_VALUE /
    NONCE / AUTH / DATA messages seen in a captured transcript.
    """
    shared = server_compute_shared(client_public_B)
    key = derive_session_key(shared)
    # ... AUTH / NONCE handling omitted (transport framing only) ...
    return key


if __name__ == "__main__":
    print("This is a reference implementation extracted for documentation")
    print("purposes only. It is not configured to run standalone.")
