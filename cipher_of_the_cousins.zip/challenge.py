#!/usr/bin/env python3
"""
Cipher of the Cousins
=====================
An ancient guild of mathematicians guarded their treasury with a
two-lock cipher.  The first lock was forged from a pair of primes
that, the guild boasted, were "as close as cousins".  The second
lock sealed the treasure with a key hidden inside the first.

We recovered the guild's encryption script (below) and the published
ciphertext.  Can you break both locks and reclaim the treasure?

Public parameters and ciphertext are in `output.txt`.
"""

from Crypto.Util.number import getPrime, bytes_to_long, long_to_bytes
from Crypto.Cipher import AES
from sympy import nextprime
import os, base64

# --- Stage 1: RSA with "cousin primes" -----------------------
# The guild intentionally generated primes that are very close.
p = getPrime(512)
q = nextprime(p + 0x10000019)        # <-- suspiciously close!
n = p * q
e = 65537
phi = (p - 1) * (q - 1)
d = pow(e, -1, phi)

# A random AES key is hidden inside the RSA ciphertext.
aes_key = os.urandom(16)
m = bytes_to_long(aes_key.hex().encode())
c = pow(m, e, n)

# --- Stage 2: AES-ECB encryption of the flag -----------------
flag = open("flag.txt", "rb").read().strip()
pad = 16 - (len(flag) % 16)
flag += bytes([pad]) * pad
ct = AES.new(aes_key, AES.MODE_ECB).encrypt(flag)
ct_b64 = base64.b64encode(ct).decode()

# --- Published values ----------------------------------------
print(f"n = {n}")
print(f"e = {e}")
print(f"c = {c}")
print(f"ct_b64 = {ct_b64}")
