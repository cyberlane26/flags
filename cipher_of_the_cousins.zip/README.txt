============================================================
  CIPHER OF THE COUSINS
  AURA CTF  -  Category: Crypto
  Estimated solve time: ~45 minutes
============================================================

CHALLENGE DESCRIPTION
---------------------
An ancient guild of mathematicians guarded their treasury with
a two-lock cipher. The first lock was forged from a pair of
primes that, the guild boasted, were "as close as cousins".
The second lock sealed the treasure with a key hidden inside
the first.

We recovered the guild's encryption script (challenge.py) and
the published ciphertext (output.txt). Break both locks and
reclaim the treasure.

FLAG FORMAT
-----------
AURA{...}

HINT
----
Cousins that share a cradle rarely keep secrets.
Fermat would nod in agreement.

FILES
-----
- challenge.py   : the guild's encryption script (source)
- output.txt     : the published RSA + AES ciphertext

TOOLS YOU MAY NEED
------------------
- Python 3 + pycryptodome
- A Fermat factorization implementation (or sage/sympy)
- Patience and a calculator that speaks modular arithmetic
