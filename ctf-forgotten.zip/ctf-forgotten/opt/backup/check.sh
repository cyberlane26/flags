#!/bin/bash

LOG="/var/tmp/.cache_data"

echo "System check completed." >> "$LOG"

# Investigation clue
echo "Look deeper into the backup directory." >> "$LOG"

